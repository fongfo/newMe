document.querySelectorAll('[data-product]').forEach((product) => {
  const options = product.querySelector('select[name="id"]');
  if (!options) return;

  const price = product.querySelector('[data-price]');
  const updatePrice = () => {
    const selected = options.selectedOptions[0];
    if (selected) price.textContent = selected.dataset.price;
  };

  if (options.selectedOptions[0]?.disabled) {
    const available = Array.from(options.options).find((option) => !option.disabled);
    if (available) options.value = available.value;
  }

  options.addEventListener('change', updatePrice);
  updatePrice();
});
